
gstName = "Sachin Tendulkar"

opponents = ['PAK', 'AUS', 'NZL', 'ENG', 'SA', 'SRI LAN', 'BAN', 'ZIM', 'WI', 'KEN']

runs = {'odi': 18500, 'tests': 15700, 't20': 3500}

def greet(gname):
    return f"Greeting {gname}, Welcome to te event....."

def sum(x, y):
    return x + y


class Player:

    def __init__(self, name, age):
        self.name = name
        self.age = age

    def get_details(self):
        print(f"Name is {self.name}\nAge is {self.age}")

    def fun(self):
        pass

    def disp(self):
        pass

    def add(self, x, y):
        return x + y

